from paraview.simple import *


sphere=Sphere()
Show()
Render()
WriteImage("addsphere.png")
