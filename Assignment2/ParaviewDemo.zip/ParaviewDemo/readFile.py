from paraview.simple import *

#read a object to the view
reader = OpenDataFile('/Applications/ParaView-5.4.1.app/Contents/data/disk_out_ref.ex2')
Show()
Render()
ResetCamera()


#change color of the object
readerRep = GetRepresentation()
readerRep.DiffuseColor = [0, 0, 1]
readerRep.SpecularColor = [1, 1, 1]
readerRep.SpecularPower = 128
readerRep.Specular = 1
Render() 

#color the object with variable
ColorBy(readerRep, ('POINTS','Pres'))
UpdateScalarBars()
Render()

#control the view
view = GetActiveView()
view.Background = [0, 0, 0]
view.Background2 = [0, 0, 0.6]
view.UseGradientBackground = True
Render() 

#plot the data
plot = PlotOverLine()
plot.Source.Point1 = [0,0,0]
plot.Source.Point2 = [0,0,10]
writer = CreateWriter('/Applications/ParaView-5.4.1.app/Contents/data/plot.csv')
writer.UpdatePipeline() 


#show the plot
plotView = CreateView('XYChartView')
Show(plot)
Render()
SaveScreenshot('/Applications/ParaView-5.4.1.app/Contents/data/plot.png') 
